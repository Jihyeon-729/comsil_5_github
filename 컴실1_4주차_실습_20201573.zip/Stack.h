#include "LinkedList.h"

//1. 템플릿 클래스로 확장해야함
//2. Stack형식으로 Delete 함수 재정의해야함
//주의: first, current_size는 class의 멤버 변수이기 때문에 this 포인터를 사용하여 가져와야함

// 템플릿 클래스로의 확장을 위해 template <class >를 선언해줌.
//LinkedList class를 상속받음
template <class T>
// LinkedList 클래스에서 확장된 형태인 LinkedList<T>를 상속받음
class Stack : public LinkedList<T>{
	public:
		bool Delete (T &element){ // 자료형 T로 확장
			//first가 0이면 false반환
			if(this->first == 0)
				return false;
			// LinkedList와 달리 Stack은 current가 가리키는 곳을 삭제
			Node <T> *current = this->first; //포인터 자료형 Node <T>로 확장
			element = this->first->data; // 제일 마지막에 들어온 데이터 element에 저장
			this->first = current->link; // first가 마지막에서 두번째로 들어온 노드를 가리키도록 해준다.
			
			delete current; // 마지막으로 들어온 노드 삭제
			this->current_size--; // 연결된 노드 개수 1 감소
			
			return true;
			}
};
